USE company
select * from emp

--getting top 5 / bottom 5 rows
select top 5* 
from emp
order by age desc

select top 5* 
from emp
order by age desc
--generate the 3 to 6 places age(i dont want top 2 age)
select * from emp
order by age desc
offset 2 rows
fetch next 3 rows only

--where clause
select *from emp
where dept ='hr'

select *from emp
where dept in('hr','worker')
order by dept

select * from emp
where age between 20 and 35

select * from emp
where age in (22,33,45)

select * from emp 
where email like 's__h%'

select * from emp 
where dept like '%[^rs]'


--findig length of the string
select len('prabhas') as length_of_word

--upper & lower case
select upper('Prabhas') as upper_case
select lower('Prabhas') as lower_case

--reverse
select reverse('Prabhas') as reverse_case
select reverse('0123456789') as reverse_case

--right,left 
select right('Prabhas',3) as right_case
select left('Prabhas',3) as left_case

select left ('its showtime',5) as left_5

select CHARINDEX('@','sandeep@sfsd') as index_position

--sub string
select SUBSTRING('fauji',/*strt position*/  3,/*length*/  2) as string_length_position

select REPLICATE('me ',5) as repeating_string
--spaceing
select 'mee' + space(1) + 'you' as joining_concatinating
select 'mee'+' you' as joining_concatinating
select 'mee'+' '+'you' as joining_concatinating

select replace('asdfghjkl@dsfja','dsfja','gmail')

