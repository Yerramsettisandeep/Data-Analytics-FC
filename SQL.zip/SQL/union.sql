create database supermarket
use supermarket

create table basket1(
	id int,
	name varchar(10)
)
insert into basket1 values(1,'apple'),
						  (2,'kiwi'),
						  (3,'banana')
insert into basket1 values(6,'orange','thej')


create table basket2(
	id int,
	name varchar(10)
)
insert into basket2 values(1,'apple'),
						  (4,'grapes'),
						  (5,'apple')

select * from basket1
--union /*union all*/ union all
select * from basket2

/*
union --combine rows more than 2 tables, it doesnt take duplicate
union all -- it takes all duplicates also
*/

alter table basket1
add supplier varchar(10)

update basket1
set supplier = case
id 
when 1 then 'ajay'
when 2 then 'vijay'
when 3 then 'akash'
else supplier
end