------------------------------------CTE (Common Table Expression)------------------------------------------
use company1

EXEC sp_helpconstraint 'emp'
select* from emp
------USING WIH ---------
with id_name as (select empid, name 
				   from emp)
select * from id_name
where name= 'suchitha'

--FINDIG AVG SALARY USING CTE

with total_avg as  (
					select avg(salary) as avg_sal
					from emp
)
select *from emp
where salary > (select * from total_avg)
--------------------
with dept_avg as (select dept, avg(salary) as avg_sal
					 from emp
					 group by dept
					)
select dept, avg_sal
from dept_avg
--where dept like '%a%'
order by avg_sal desc
----------------------

WITH dept_avg AS (
    SELECT dept, AVG(salary) AS avg_sal
    FROM emp
    GROUP BY dept
)
SELECT * from dept_avg
where avg_sal >(
	select avg(avg_sal) 
	from dept_avg
	)


---------------------

WITH dept_avg AS (
    SELECT dept, AVG(salary) AS avg_salary
    FROM emp
    GROUP BY dept
)
SELECT TOP 1 dept, avg_salary
FROM dept_avg
ORDER BY avg_salary DESC;


---max salaries
with max_salary as
		(
		 select dept, max(salary) as max_Salary
		 from emp
		 group by dept
		)
select e.name, m.dept, m.max_salary
from emp e
join max_salary m
on e.dept = m.dept and e.salary = m.max_salary

select * from emp

---find dept where the count of employees is more than avg count of all dept
with emp_count AS (
    select dept, count(*) AS count_of_emp
    from emp
    group by dept
),
avg_count as (
    SELECT AVG(count_of_emp) AS avg_emp_count
    FROM emp_count
)
SELECT e.dept, e.count_of_emp
FROM emp_count e
CROSS JOIN avg_count a
WHERE e.count_of_emp > a.avg_emp_count;

-----------OR----------
with avg_count as (
		select dept, count(*) as dept_count
		from emp
		group by dept
)
select dept, dept_count
from avg_count
where dept_count > (
		select avg(dept_count)
		from avg_count
)

select* from emp