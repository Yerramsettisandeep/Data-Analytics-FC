create database family

use family

create table grand_parent(
	id int,
	name varchar(30),
	kid int
)
insert into grand_parent values
(1, 'ajay', 4),
(2, 'vijay', 6),
(3,'sam', 5),
(4, 'bob', null),
(5, 'john', null),
(6, 'jessy', null)


-------------------------------------------------------self join-----------------------------------------------------------------
select p.name as parent_name, c.name as child_name
from grand_parent p
left join grand_parent c
on p.kid=c.id

--right join
select p.name as parent_name, c.name as child_name
from grand_parent p
right join grand_parent c
on p.kid=c.id

--inner join
select p.name as parent_name, c.name as child_name
from grand_parent p
inner join grand_parent c
on p.kid=c.id

select * from grand_parent
drop table grand_parent


create table office(
	empid int,
	name varchar(30),
	manager_id int
)

insert into office values
(1,'siva',6),
(2,'swe',4),
(3,'ani',5),
(4,'san',null),
(5,'deep',null),
(6,'ram',null)

select e.name as mng, m.name as emp
from office e
inner join office m
on e.manager_id = m.empid

create table manager(
	empid int,
	emp_name varchar(30),
	mid int
)

insert into manager values
(1,'arpit',3),
(2,'shwetha',3),
(3,'sowmya',5),
(4,'ajay',null),
(5,'vijay',null)

select e.emp_name as emp, m.emp_name as mgr
from manager e
inner join manager m
on e.mid=m.empid
