create database sql_exam_practice
use sql_exam_practice

CREATE TABLE emp (
    empid INT IDENTITY(1,1) PRIMARY KEY,
    emp_name VARCHAR(30),
    dept VARCHAR(30),
    salary INT,
    city VARCHAR(30),
    joindate DATE
);

INSERT INTO emp (emp_name, dept, salary, city, joindate)
VALUES
('Rohit', 'IT', 50000, 'Hyderabad', '2022-01-10'),
('Anita', 'HR', 45000, 'Delhi', '2021-05-12'),
('Suresh', 'IT', 60000, 'Mumbai', '2020-03-15'),
('Priya', 'Finance', 55000, 'Chennai', '2022-07-20'),
('Kiran', 'HR', 40000, 'Delhi', '2021-11-25'),
('Asha', 'IT', 70000, 'Hyderabad', '2019-09-05');

SELECT * FROM emp;

UPDATE emp
SET salary = 48000
WHERE emp_name = 'Anita';

DELETE FROM emp
WHERE emp_name = 'Kiran';

alter table emp
alter column emp_name varchar(30) not null

alter  table emp
add constraint df_emp_joindate
default getdate() for joindate

alter  table emp
add constraint ck_emp_salary
check (salary >=10000)

alter  table emp
add constraint uq_emp_emp_name
unique (emp_name)

INSERT INTO emp (emp_name, dept, salary, city)
VALUES ('Manoj', 'IT', 55000, 'Bangalore');
-------substring--------------
select emp_name,len(emp_name) as name_length from emp
select emp_name,upper(emp_name) as name_length from emp
select emp_name,left(emp_name,3) as name_length from emp
select emp_name,right(emp_name,2) as name_length from emp
select emp_name,substring(emp_name,3,2) as name_length from emp
select concat(emp_name,'-',dept) as name_length from emp
select emp_name,reverse(emp_name) as name_length from emp
SELECT REPLACE(emp_name, 'a', '@') AS replaced_name FROM emp;

select count(*) from emp
where dept='it'

select sum(salary)from emp
select avg(salary)from emp
select min(salary) from emp
select max(salary)from emp

select dept,sum(salary) from emp
group by dept

select dept,avg(salary) from emp
group by dept

select city,count(*) from emp
group by city 

select dept,avg(salary) from emp
group by dept
having avg(salary) > 50000

select dept, max(salary) from emp
group by dept

select city, count(*) from emp
group by city
having count(*)>1

select dept,sum(salary)from emp
group by dept
having sum(salary) >56500

select dept, count(*) from emp
where city = 'hyderabad'
group by dept

SELECT * FROM emp
WHERE dept NOT IN ('IT');

SELECT * FROM emp
WHERE dept IN ('IT', 'HR');

SELECT * FROM emp
WHERE city NOT IN ('Delhi');

select * from emp
where emp_name like 's%'

select * from emp
where dept = 'it' or dept = 'finance'

select * from emp
where salary between 50000 and 70000

select * from emp
order by empid
offset 2 rows
fetch next 3 rows only

select distinct city from emp

----------------------------JOINS---------------------------------

create table dept(
	deptid int primary key,
	dept_name varchar(30)
)

INSERT INTO dept VALUES
(1, 'IT'),
(2, 'HR'),
(3, 'Finance');

CREATE TABLE emp_join (
    empid INT PRIMARY KEY,
    emp_name VARCHAR(30),
    deptid INT
);
INSERT INTO emp_join VALUES
(1, 'Rohit', 1),
(2, 'Anita', 2),
(3, 'Suresh', 1),
(4, 'Priya', 3),
(5, 'Kiran', NULL);

--INNER JOIN
select d.dept_name, e.emp_name
from dept d
inner join emp_join e
on e.deptid=d.deptid

--Left join
select e.emp_name, d.dept_name
from emp_join e
left join dept d
on e.deptid=d.deptid

--RIGHT JOIN
select e.emp_name, d.dept_name
from emp_join e
right join dept d
on e.deptid=d.deptid

--Full OUTER JOIN
select e.empid, e.emp_name,d.dept_name
from emp_join e
full join dept d
on e.deptid = d.deptid

--join with where
select e.empid, e.emp_name,d.dept_name
from emp_join e
inner join dept d
on e.deptid=d.deptid
where d.dept_name = 'it'
--
select e.emp_name,d.dept_name
from emp_join e
left join dept d
on e.deptid=d.deptid
where d.deptid is null

select d.dept_name
from emp_join e
left join dept d
on e.deptid=d.deptid
where e.empid is null

select d.dept_name,count(e.empid)
from dept d
left join emp_join e
on d.deptid=e.deptid
group by d.dept_name

select e.emp_name, d.dept_name
from emp_join e
inner join dept d
on e.deptid = d.deptid
where d.dept_name in ('it','hr')

select e.emp_name, d.dept_name
from emp_join e
join dept d
on e.deptid = d.deptid

select e.emp_name, d.dept_name
from emp_join e
right join dept d
on e.deptid = d.deptid
where d.deptid is not null

select d.dept_name, count(e.empid)
from emp_join e
join dept d
on d.deptid=e.deptid
group by d.dept_name

select e.emp_name, d.dept_name
from emp_join e
full join dept d
on e.deptid=d.deptid

--SUBQUERY
SELECT * from emp
where salary > (select avg(salary) from emp)

select * from emp where dept = (select dept from emp
where dept in ('hr', 'it'))

select emp_name from emp_join
where deptid=(select deptid from dept
where dept_name='it')

select emp_name from emp_join
where deptid not in (select deptid from dept)

select e1.* from emp e1
where salary > (select avg(salary) from emp e2
where e1.dept=e2.dept)

--CTE
with emp_cte as(
    select * from emp
) select * from emp_cte;
--------------
with avg_sal as(
    select avg(salary) as avg_salary
    from emp
)
select * from emp
where salary > (select avg_salary from avg_sal)
------------
with emp_basic(id,name,dept,salary) as(
        select empid,emp_name,dept,salary
        from emp
)
select name, salary from emp_basic
------------
with it_emp as(
        select * from emp
        where dept='it'
)
select * from it_emp
------------
with dept_sal as(
        select dept, avg(salary) as avg_sal
        from emp 
        group by dept
)
select *
from dept_sal
-------------
with emp_dept as(
        select e.emp_name,d.dept_name
        from emp_join e
        inner join dept d
        on e.deptid=d.deptid
)
select * from emp_dept
------------
with cte_sal as
(select * from emp
where salary > 50000)
select * from cte_sal
------------
with ctedept_sal as
(select dept, sum(salary) as total_sal
from emp
group by dept)
select * from ctedept_sal
-------------
with it_name as
(select emp_name from emp
where dept ='it')
select * from it_name
-------------CASE
SELECT emp_name,salary,
case
    when salary >= 60000 then 'high'
    when salary >= 55000 then 'medium'
    else 'Low'
end as salary_level
from emp
-------------
update emp
set salary =
case 
    when dept = 'it' then salary + 5000
    when dept = 'hr' then salary + 3000
    else salary +2000
end
------------
SELECT
case
    when salary >= 60000 then 'high'
    when salary >= 55000 then 'medium'
    else 'Low'
end as salary_level,
count(*) as emp_count
from emp
group by 
case 
    when salary >= 60000 then 'high'
    when salary >= 55000 then 'medium'
    else 'Low'
end
---------------
select emp_name,
case 
    when salary>60000 then 'senior'
    else 'junior'
end as level
from emp
--------------WINDOWS FUN---------------------
select emp_name,salary,
row_number() 
over(order by salary desc) as row_num
from emp
----
select *,
rank() over(
    --partition by dept
    order by salary desc
)
from emp
-------
select emp_name, salary,
ntile(4) over(
    order by salary desc
) as sal_grp
from emp
-----------
SELECT emp_name, dept, salary,
sum(salary) OVER (PARTITION BY dept) AS max_dept_salary
FROM emp;
------
select *,
dense_rank()over(
    order by salary desc
) as sal_rank
from emp
--------
select *,
rank() over(
    --partition by dept
    order by city 
)
from emp
---------
select *,
min(salary) over(partition by dept) 
from emp
---------
select *,
ntile(3) over(
    order by salary
)
from emp
---------
SELECT *,
salary - lag(salary) over(
    order by dept
)as prev_sal
from emp
-------
SELECT emp_name, dept, salary,
salary - LAG(salary) OVER (
    PARTITION BY dept
    ORDER BY salary
) AS dept_salary_diff
FROM emp;















select * from emp_join
select * from dept
select* from emp
/*
create table emp(
	empid int identity(1,1) primary key,
	emp_name varchar(30) not null,
	dept varchar(30),
	salary int,
	City varchar(30),
	joindate date default getdate()
)

insert into emp (emp_name, dept, salary, city) values 
('Rohit', 'IT', 50000, 'Hyderabad'),
('Anita', 'HR', 45000, 'Delhi'),
('Suresh', 'IT', 60000, 'Mumbai'),
('Priya', 'Finance', 55000, 'Chennai'),
('Kiran', 'HR', 40000, 'Delhi'),
('Asha', 'IT', 70000, 'Hyderabad');



select*from emp
drop table emp

select * from emp
where salary>50000

select * from emp
where dept='hr' or city ='mumbai'

select distinct dept
from emp

select top 3* from emp
order by salary desc

select top 2* from emp
where dept = 'it'
order by salary desc

select * from emp
where city ='delhi'

select top 1* from emp
order by salary desc

select distinct city
from emp

select top 3* from emp
order by salary desc

select * from emp
where dept = 'it'
order by salary desc

update emp
set salary = 52000
where emp_name = 'rohit'

update emp
set salary = salary +(salary*10/100)
where dept = 'it'

update emp
set dept = 'Senior IT'
where salary >70000

delete from emp
where emp_name='kiran'

update emp
set salary = salary+5000
where dept = 'hr'

update emp
set city = 'Bangalore'
where emp_name='priya'

delete from emp
where salary = (select max(salary) from emp)

alter table emp
add email varchar(40)

alter table emp
add status varchar(10) default 'Active'

ALTER TABLE emp
DROP CONSTRAINT DF__emp__status__60A75C0F;
alter table emp
drop column status

alter table emp 
alter column empid int not null
alter table emp
add constraint pk_emp_empid
primary key(empid)

ALTER TABLE emp
ADD CONSTRAINT uq_emp_email
UNIQUE (email);

alter table emp
alter column email varchar(40) null

select * from emp
*/
drop table emp