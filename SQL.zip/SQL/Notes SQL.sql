﻿-------------------Lesson 1 — SQL Basics & First Table
--Create a database
CREATE DATABASE SQLMasterDB;
USE sqlmasterdb;


--creatinging Table in the database
CREATE TABLE Students (
    StudentID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Age INT NULL,
    Email VARCHAR(100) UNIQUE,          -- added unique constraint
    EnrollDate DATE DEFAULT GETDATE()
);


--Inserting rows into the table
INSERT INTO Students (FirstName, LastName, Age, Email)
VALUES ('Rohit', 'Kumar', 20, 'rohit@mail.com');

INSERT INTO Students (FirstName, LastName, Age)
VALUES ('Anita', 'Sharma', 22);    -- no email given

INSERT INTO Students (FirstName, LastName, Age, Email)
VALUES 
 ('Suresh', 'Reddy', 21, 'suresh@mail.com'),
 ('Priya',  'Das',   19, 'priya@mail.com');


-- Query to run the table
select * from Students;

---------------Lesson 2 — SELECT & FILTERING (WHERE) + ORDER & Basic Functions
--SELECT columns from a table
-- Select specific columns
SELECT FirstName, LastName 
FROM Students;


-- Select specific columns with an expression
SELECT StudentID, FirstName + ' ' + LastName AS FullName
FROM Students;

--SELECT ALL
SELECT * FROM Students;
/*
Notes:
        * means everything → all columns.
        Good for quick view, not for reports.
*/

--WHERE — Filter rows
-- Students older than 20
select * 
from Students
where age > 20;

-- Students aged 19 or 20
select * from students
where age =19 or age = 20;

-- Students whose age is between 18 and 22
select * from students
where age between 18 and 22;
/*
Notes:
        WHERE tells SQL which rows to show.
        Use =, >, <, >=, <=
        Combine conditions with AND, OR
*/



--WHERE with AND / OR
-- Age >= 20 AND email not null
select * from students
where age>=20 and email is not null;

-- Age = 19 OR Age = 21
select * from students
where age =19 or age=21;
/* Notes:
        AND → both conditions must be TRUE
        OR → either condition
*/


--WHERE with NULL
--Students with no email saved
select * from students
where email is null;
/*
Notes:
    NULL ≠ value; it means empty / unknown
    You must use IS NULL or IS NOT NULL
*/


--ORDER BY — sort the results
--Sort by LastName ascending (A → Z)
select * from students
order by lastname;

--Sort by Age (highest → lowest)
select * from students
order by age desc;
/*
Notes:
    Default is ascending (ASC) if you don’t write it.
    DESC means descending.
*/


--TOP — take first few rows
/*
Notes:
TOP returns the first few rows from sorted data or table directly.
*/
--find Top 2 students
select top 2  *
from students;

--Aggregate functions — COUNT
--Count all students
select count(*) as total_students
from students

--Count students who have email
select count(Email) as student_emails
from students

/*
Notes:
    COUNT(*) counts rows
    COUNT(column) counts only non-null values
*/
/*
-------------------------Practice Exercises----------------------------
Exercise 1
Select only FirstName and Age of all students.
select firstname, age 
from students;

Exercise 2
Show students who are age 21 or above.
select * from students
where age >= 21;

Exercise 3
Show students who do not have an email.
select * from students
where email is null;

Exercise 4
Show all students ordered by Age descending.
select * from students
order by age desc;

Exercise 5
Show the top 3 youngest students.
select top 3 * from students
order by age

Exercise 6
Count how many students are there in total.
select count(*) as total_students 
from students;

------------Mini Quiz--------------------
What does WHERE do?
wher does filtering the row and gives the data ehich we want
How to filter null email?
by using is null in where
What keyword sorts data?
order by
How to show only first 2 rows?
by using top 2
*/

------------------------Lesson 3 — INSERT, UPDATE, DELETE (DML Commands)
/*
NOTE:
    DML = Data Manipulation Language
    These commands are used to add, change, and remove data inside a table.
*/

----INSERT (Add new records)
/*
SYNTAX:
INSERT INTO table_name (columns)
VALUES (values);
*/
--Insert a single row
INSERT INTO Students (FirstName, LastName, Age, Email)
VALUES ('Rohit', 'Sharma', 20, 'rohitsharma@mail.com');

INSERT INTO Students (FirstName, LastName, Age, Email)
VALUES ('Varun', 'Teja', 19, 'varun@mail.com');

--Insert multiple rows at once
INSERT INTO Students (FirstName, LastName, Age, Email)
VALUES 
('Sandeep', 'Yerramsetti', 22, 'sandeep@mail.com'),
('Kiran', 'Kumar', 23, 'kiran@mail.com'),
('Asha', 'Reddy', 21, 'asha@mail.com');
select* from students


-----UPDATE (Modify existing data)
/*
NOTE:
    UPDATE is used when you want to change a value in an existing row.
    Always use WHERE, otherwise every row will change.
*/
--Update One Column (Simple Update)
--Example: Change Varun’s age from 19 → 20
UPDATE STUDENTS
set age = 20
where firstname = 'varun';

--Update Multiple Columns Together
--Example: Update Kiran’s Age + Email
update students
set age = 24,
    email = 'kiran.new@mail.com'
where firstname = 'kiran'

--Update NULL Values
--Your table has one NULL email:
update students
set email = 'anita@mail.com'
where email is null

--CASE in UPDATE
--It allows you to update values differently based on some conditions in a single UPDATE query.
update students
set age = case
    when firstname ='rohit' then 21
    when lastname = 'Y Sandeep' then 23
    else age
end


----DELETE (Remove rows)
---DELETE removes rows permanently from the table.

--ex: Delete Priya (Age = 19):
DELETE FROM Students
WHERE FirstName = 'Priya';

--Delete Based on Condition
-- ex: Delete students whose Age < 20:
delete from students
where age <20;

/*
--Practice Exercises (Write + Execute)
--Exercise 1: Update Sandeep’s LastName to “Y Sandeep”

update students
set lastname = 'Y Sandeep'
where firstname = 'Sandeep'

--Exercise 2: Change Asha’s age to 22
update students
set age =22
where firstname ='asha'

--Exercise 3
--Update all students aged 21 to age 22
update students
set age=22
where age=21

--Exercise 4
--Delete the student whose LastName is Das (Priya)
delete from students
where lastname = 'das'

--Exercise 5
--Delete all students whose age is 19
delete from students
where age = 19

--Exercise 6
--Update email of Anita (NULL one) to:anita.new@mail.com
update students 
set email = 'anita.new@mail.com'
where firstname='anita'

------------- Mini Quiz
What happens if UPDATE has no WHERE?
it will update every column
How do you delete only one row?
by selecting the primary key(id),unique in where we can delete entire column
Can we update two columns at once?
yes
What does DELETE FROM Students do?
it delets the data permently
*/

-----------------------------ORDER BY, TOP, and OFFSET FETCH------------

--ORDER BY (Sorting Results)
--Used to sort rows in ascending (ASC) or descending (DESC) order.

--Example 1: Sort by First Name (A → Z)
SELECT * FROM Students
ORDER BY FirstName ASC;

--Example 2: Sort by Age (Highest first)
SELECT * FROM Students
ORDER BY Age DESC;

--Example 3: Sort by LastName then FirstName
SELECT * FROM Students
ORDER BY LastName ASC, FirstName ASC;

---TOP – Limit number of rows
--Example: Show TOP 3 youngest students
SELECT TOP 3 * FROM Students
ORDER BY Age ASC;

--Example: Show TOP 1 latest enrolled student
SELECT TOP 1 * FROM Students
ORDER BY EnrollDate DESC;

--OFFSET…FETCH – Pagination
--Used when you want to show data in pages (like in apps).
/*
Syntax:
    ORDER BY <column>
    OFFSET X ROWS
    FETCH NEXT Y ROWS ONLY;
*/
--Example: Skip first 2 records, show next 3
select *from students
order by studentid
offset 2 rows
fetch next 3 rows only;


--Example: Skip first 5 students, show next 5
select * from students
order by studentid
offset 5 rows
fetch next 5 rows only;

select * from students
order by Age desc, LastName asc



--ALTER TABLE(ADD COLUMN)
--ALTER TABLE means changing the structure of the table after it is created.
--ADD COLUMN
alter table table_name
add column column_name;

SELECT * FROM students
-----------------------------------JOINS---------------------------
CREATE TABLE Departments (
    Department_ID INT PRIMARY KEY,
    Department_Name VARCHAR(50)
);

-- Insert some sample data
INSERT INTO Departments VALUES
(1, 'Computer Science'),
(2, 'Mechanical'),
(3, 'Electronics'),
(4, 'Civil');

alter table students
add department_id int null;

update students
set department_id = 1
where studentid in(1,3,6)

UPDATE Students 
SET department_id = 2 
WHERE StudentID IN (2,5,7);

UPDATE Students 
SET Department_ID = 3 
WHERE StudentID IN (4,9);

UPDATE Students 
SET Department_ID = 4 
WHERE StudentID = 8;

alter table students
add constraint fk_students_department
foreign key (department_id) references departments(department_id)


select s.firstname, s.lastname, s.age,d.department_name
from students s
inner join Departments d
on s.department_id = d.department_id






select * from students
select * from Departments