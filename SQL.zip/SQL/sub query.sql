create database company1
use company1

create table emp (
	empid int identity(101,1) primary key,
	name varchar(30),
	age int,
	dept varchar(20),
	salary int,
	doj date,
	gender varchar(10)
)

insert into emp values
('ravi', 27, 'hr', 38000,'2018/12/04','male'),
('vinod', 30, 'it', 38000,'2020/05/06','male'),
('kavya', 34, 'sales', 25000,'2020/09/09','female'),
('swetha', 23, 'hr',31333,'2021/11/11','female'),
('suchitha', 22, 'sales', 30000,'2021/01/15','female'),
('vijay', 24, 'hr', 34000,'2022/12/04','male'),
('ajay', 24, 'it', 33000,'2022/02/24','male'),
('antony', 34, 'sales', 30000,'2022/08/15','male'),
('thej',33, 'it', 40000,'2023/12/04','female'),
('joshna', 30, 'sales', 28000,'2023/12/04','female')

/*
--updating salary for vinod 39000
update emp
set salary=39000
where name = 'vinod'
*/

select * from emp

--display 2nd highest salary employee details
select * from emp 
order by salary desc
offset 1 rows
fetch next 1 rows only

--display avg salary   from each gender
select gender,avg(salary) from emp
group by gender
--find details of highest salary
select *  from emp
where salary =(select max(salary) from emp)
----------------------------------------------sub query---------------------------------------------------------

--finding 2nd highest salary

select * from emp
where salary<40000


select * from emp 
where salary= (select max(salary) from emp
where salary < (select max(salary) from emp))

select * from emp 
select avg(salary) from emp

--find above avg salary employees
select * from emp
where salary>(select avg(salary) from emp)
--where salary >(select avg(salary) from emp )) for top 2 highest avg salary


------------------------------------------------corelation sub query------------------------------------------------
--group by dept wise salary
select * from emp 
where salary > (select dept,max(salary) from emp
				group by dept)

select dept, max(salary) as highest_salary
from emp
group by dept;


---sub query max salary without using group by 
select *from emp e
where salary = (select max(salary) from emp f
where e.dept = f.dept)

---sub query avg salary without using group by
--error
select * from emp e
where salary > (select dept , avg(salary) from emp e
where salary = (select avg(salary) from emp f
where e.dept = f.dept))
--error

select max(salary) from emp
select * from emp
order by salary desc

---grp by dept which creats a temp table
select * from (
select dept, avg(salary) as avg_salary
from emp
group by dept) as xyz

---grp by dept which creats a temp table and finding highest salary
select top 1 dept, avg_salary
from (
		select dept, avg(salary) as avg_salary
		from emp
		group by dept
) 
as xyz
order by dept desc
-------------------------------------------------
SELECT dept, avg_salary
FROM (
    SELECT dept, AVG(salary) AS avg_salary
    FROM emp
    GROUP BY dept
) AS xyz
ORDER BY avg_salary DESC;



select * from emp
-------------------------------------------
---find dept where emp count is more than dept count
select dept, count(*) as dept_count
from emp
group by dept
having count(*)>=(	
					select avg(dept_count) as total_avg_emp
					from(
							select dept, count(*) as emp_count
							from emp
							group by dept
					) as total_avg
				) as max_total_avg


----find ppl in each dept whose sal is more than avg sal in there dept 
select max(avg_salary)
from(
	select dept, avg(salary) as avg_salary
	from emp
	group by dept) as 


/*	where max(avg_salary) >( select dept,salary
							from emp
							
							)
							as max_avg_sal*/

select * from emp
---Find employees who earn more than average salary
select * from emp
where salary >(select avg(salary) from emp);


--Find employees who work in departments that have more than 5 employees
select* from emp
where dept in (select dept from emp group by dept having count(*)>5)

--Employees who earn more than any salary in HR
select * from emp
where salary > any
(select salary from emp where dept='hr')
--Employees who earn more than all salaries in HR
select * from emp
where salary > all
(select salary from emp where dept = 'hr')

--MULTI-COLUMN SUBQUERY
--Find employees whose (dept, salary) pair matches 
--highest salary of each dept

select name, dept,salary
from emp 
where (dept, salary) in(
	select dept,max(salary) 
	from emp
group by dept
)

---CORRELATED SUBQUERY
--Find employees who are highest salary in each dept
select dept,max(salary) as highest_salary
from emp
group by dept

--Find employees who are highest salary in each dept
select e1.*
from emp e1
where salary = (select max(salary) 
from emp e2
where e2.dept=e1.dept
)

--Find employees who earn more than department average
select e1.*
from emp e1
where salary = (select avg(salary)
from emp e2
where e2.dept = e1.dept)

--Find employees who earn more than the average salary
select * from emp 
where salary >(select avg(salary) from emp)

--Highest salary employee from each department
select e1.*
from emp e1
where salary = (select max(salary) from emp e2
where e1.dept = e2.dept
)

------------------------------CTE---------------------------------
--List employees with salary greater than average USING CTE
with avg_sal as
(select avg(salary) as avg_salary from emp)
select name, salary
from emp,avg_sal
where salary>avg_salary

--CTE to get the highest salary per department
with high_salary as 
	(
	 select dept, max(salary) as high_sal
	 from emp
	 group by dept
	)
select e.*
from emp e
join high_salary h
	on e.dept=h.dept
	and e.salary = h.high_sal

