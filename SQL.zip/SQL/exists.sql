create database sp
use sp

create table prof(
		pid int,
		p_name varchar(20),
)
insert into prof values(1,'p1'),
						(2,'p2'),
						(3,'p3')


create table st (
		sid int,
		name varchar(20),
		mentorid int,
		gender varchar(1)
)
insert into st values
(101,'ravi',2,'m'),
(102,'sujana',1,'f'),
(103,'surya',3,'m'),
(104,'anaya',2,'f'),
(105,'veru',1,'m'),
(106,'sowmya',3,'f'),
(107,'vinod',3,'m')

--get empid and name of prof whos is an adv at least 1 f student
select s.name,p.pid, p.p_name
from prof p
inner join st s
on p.pid=s.mentorid
where s.gender = 'f'

--

select p.pid,p.p_name
from prof p
where exists (select 1 
			  from st s
			  where
			  s.gender = 'f' and
			  s.mentorid = p.pid
)

---select dept where atleast 1 emp working

--dept --depid, deptname insert values1234
--emp-- empid,empname,did  insert values123
select d.deptid, d.deptname
from dept d
where exists(select 1 from emp e
			 where d.deptid=e.did)



select * from st
select * from prof