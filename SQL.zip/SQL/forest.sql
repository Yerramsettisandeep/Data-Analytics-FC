create database forest
use forest

create table animals(
    id int identity(500,1) primary key,
    name varchar(20),
    age int
)

insert into animals values
('Lion', 8),
('Tiger', 6),
('Elephant', 25),
('Deer', 4),
('Monkey', 3),
('Giraffe', 12),
('Zebra', 7),
('Wolf', 5),
('Bear', 10),
('Fox', 4)


create table care_taker(
    aid int primary key,
    ct_name varchar(20),
    no_of_years int
)

insert into care_taker values
(501, 'Ravi', 5),
(512, 'Kiran', 3),
(503, 'Suresh', 8),
(514, 'Akhil', 2),
(505, 'Mahesh', 6),
(516, 'Rohit', 4),
(507, 'Sam', 7),
(518, 'Vikram', 3),
(509, 'Arun', 9),
(510, 'John', 1)

/*joins
join/inner join
right / right inner
left / left inner
full / full outer
*/

--inner join
select a.id, a.name, c.ct_name
from animals a
inner join care_taker c
on a.id=c.aid


--left join
--if animal as left table
select a.id,a.name,c.ct_name
from animals a --left
left join care_taker c  --right
on a.id=c.aid


--if care_taker as left table
select c.ct_name, a.id, a.name
from care_taker c --left
left join animals a  --right
on a.id=c.aid



--right join
--if animals in right
select a.id, a.name,c.ct_name
from animals a  --right
right join care_taker c --left
on a.id = c.aid


--if care_taker in right
select a.id, a.name,c.ct_name
from care_taker c  --right
right join animals a --left
on a.id=c.aid

--full join
select a.id, a.name, c.ct_name
from animals a
full join care_taker c
on a.id = c.aid

--cross join
select a.id, a.name, c.ct_name
from animals a
cross join care_taker c
 
select *from animals
select * from care_taker



drop database forest
drop table animals
drop table care_taker





create table emp(
id int primary key,
name varchar(30)
)

insert into emp values
(101, 'ajay'),
(102, 'vijay'),
(103, 'ans'),
(104, 'adfy'),
(105, 'drgay')

create table dept(
empid int,
deptin varchar(30)
)
insert into dept values
(101,'hr'),
(103,'it')



--display emp working  r not in any dept
select e.id, e.name, d.deptin
from emp e
left join dept d
on e.id=d.empid
where d.empid is null

--display emp working in any dept
select e.id, e.name, d.deptin
from emp e
inner join dept d
on e.id=d.empid

select e.id, e.name, d.deptin
from emp e
right join dept d
on e.id=d.empid

--display all emp and their dept
select e.id, e.name, d.deptin
from emp e
full join dept d
on e.id=d.empid