use company3
select * from emp

insert into emp values(109, 'Sam', 24, 'IT', 7000);


--Windows function- extra columns

--rank- position
--dense_rank-- next number

SELECT *,
     dense_rank() OVER (
	 --partition by dept
     ORDER BY doj
    ) AS rank_doj
FROM emp


SELECT *,
row_number() OVER (PARTITION BY dept ORDER BY salary desc) AS row_no,
rank() OVER (PARTITION BY dept ORDER BY salary desc) AS rank_no,
dense_rank() OVER (PARTITION BY dept ORDER BY salary desc) AS denserank_no
FROM emp;

use employee
SELECT *,
    row_number() OVER (
        PARTITION BY department 
        ORDER BY salary desc
    ) AS row_no
FROM emp;

select * from emp
order by salary desc

SELECT *,
   max(salary) OVER (
        PARTITION BY dept
        ORDER BY doj
    ) AS min_salary
FROM emp;

SELECT *,
    min(salary) OVER ( PARTITION BY dept ORDER BY name) AS salary_min,
	max(salary) OVER (PARTITION BY dept ORDER BY name) AS salary_max,
	sum(salary) OVER (PARTITION BY dept ORDER BY name) AS salary_total,
	avg(salary) OVER (PARTITION BY dept ORDER BY name) AS salary_average
FROM emp


insert into emp values('xxx','IT','25',3500) 


SELECT *,
    lead(salary) OVER (
        --PARTITION BY dept 
        ORDER BY empid 
    ) AS next_ones_salary
FROM emp;


SELECT *,
row_number() OVER (PARTITION BY dept ORDER BY salary desc) AS row_no,
rank() OVER (PARTITION BY dept ORDER BY salary desc) AS rank_no,
dense_rank() OVER (PARTITION BY dept ORDER BY salary desc) AS denserank_no,
lead(salary) OVER (PARTITION BY dept ORDER BY empid ) AS next_salary, 
lag(salary) OVER (PARTITION BY dept ORDER BY empid ) AS previous_salary 
FROM emp;

SELECT *,
    sum(salary) OVER (
        --PARTITION BY dept
        ORDER BY empid 
    ) AS max_salary
FROM emp;


SELECT *,
    first_value(name) OVER (
        --PARTITION BY dept
        ORDER BY empid
    ) AS first_emp 
FROM emp;

SELECT *,
    last_value(name) oVER (
        --PARTITION BY dept 
        ORDER BY empid 
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
    ) AS last_name
FROM emp;

SELECT *,
    NTILE(4) OVER (
        --PARTITION BY dept
        ORDER BY age
    ) AS group_people
FROM emp;



--ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING


--rank
--dense rank
--row number
--lead
--lag
--agg- sum, avg, min, max
--first value
--last value
--ntile






