---DCL,TCL,TRUNCATE-----

use company

-----TRUNCATE-------(only for values in all rows)
--it removes the data, but the table column names will be visible and 
--its can be get back by using (ROLLBACK tableName)
BEGIN TRAN		---- strt transaction

truncate table emp		-----empties the table

select * from emp		-----check after the truncate

rollback tran	---- to get back the data; its like undo

-----DELETE-----------(ONLY for rows)
BEGIN TRAN		---- strt transaction

delete from emp where emp_id='7'		-----empties the table

select * from emp		-----check after the truncate

rollback tran	---- to get back the data; its like undo

------DROP----(ELIMINATE COMPLETELY)
DROP TABLE xxx
drop database XXX



----------GRANT,REVOKE(DCL)----
CREATE LOGIN mynetflix with password 'nopassword'
create user ravi for login mynetflix
grant 
select on emp
to raj

revoke
select on emp
from raj

-------------TCL(commit,savepoint)
--COMMIT : we are fixing permentaly
begin tran

update emp
set age = age+1
where age = 33

commit

select * from emp

rollback tran

--save point
begin tran

update emp
set age = age+1
where age = 24
save tran s1

update emp
set age = age+3
where age = 25
save tran s2

update emp
set age = age+1
where age = 32
commit
rollback tran s2
select * from emp

