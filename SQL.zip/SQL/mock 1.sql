create database companyex
use companyex

create table emp(
    emp_id int primary key,
    name varchar(30) not null,
    dept varchar(10) not null,
    salary int check (salary > 0)
)

insert into emp values
(1, 'rohit', 'hr', 30000),
(2, 'anita', 'it', 45000),
(3, 'suresh', 'fin', 50000),
(4, 'kiran', 'it', 42000),
(5, 'meena', 'hr', 32000),
(6, 'raj', 'fin', 48000),
(7, 'sai', 'it', 46000),
(8, 'tina', 'hr', 31000)


create table personal_details(
    emp_id int primary key,
    contact_no varchar(15) unique,
    email varchar(40) unique,
    foreign key (emp_id) references emp(emp_id)
)

insert into personal_details values
(1, '9876543210', 'gg@mail.com'),
(2, '9988776655', 'ww@mail.com'),
(3, '9900112233', 'ss@mail.com'),
(4, '8877665544', 'mm@mail.com'),
(5, '7766554433', 'yy@mail.com')

create table dept_details(
    dept varchar(10) primary key,
    dept_id int unique
)

insert into dept_details values
('hr', 101),
('it', 102),
('fin', 103)

--foreign key constraint
alter table emp
add constraint fk_emp_dept
foreign key (dept) references dept_details(dept);



--1.join all emp details like name,contact_no,email, dept
select e.name, p.contact_no, p.email, d.dept_id
from emp e
join personal_details p 
    on e.emp_id = p.emp_id
join dept_details d 
    on e.dept = d.dept

--2.name dept where more than 2 emp are working
select dept,count(*) from emp
group by dept
having count(*)>2

--3.avg salary from each dept
select dept,avg(salary) from emp
group by dept

--4.emp who earns more than avg sal from each dept
select e.* from emp e
where salary >
    (select avg(salary) from emp 
    where dept = e.dept)

---5.add column in emp - joining date ad fill date
alter table emp
add joining_date date;

update emp
set joining_date = case
    when emp_id = 1 then '2018-02-05'
    when emp_id = 2 then '2019-03-10'
    when emp_id = 3 then '2020-01-15'
    when emp_id = 4 then '2021-07-20'
    when emp_id = 5 then '2017-11-25'
    when emp_id = 6 then '2018-06-30'
    when emp_id = 7 then '2019-09-18'
    when emp_id = 8 then '2020-12-01'
end


--6.find top 5 emps joined company 
select top 5 * from emp
order by joining_date desc

--7 rank based on salary
select *,
rank() over(
partition by dept
order by salary desc
)
from emp

--8.find dept where avg sal is more than 10k
select * from emp 
where salary >(select avg(salary) from emp
where salary>10000
)



--9. divide 3 grps basec on names
select *,
	ntile(3) over(
	order by name
	) as name_grp
from emp

--10.

--11.display emp and their joining
select name, joining_date
from emp


--12.emp name 
select name, 


--13. all emp in it dept
select * from emp
where dept = 'it'


--14.get name sof emp name starts with a or b
select * from emp
where name like '[ab]%'

--14.get name sof emp name starts with a or b
select * from emp
where name like 'a%' or name like 'b%'

--15.highest sal in each dept
select dept, max(salary)
from emp
group by dept


--16.previous emp name 
select * ,
	lag(name) over(
	order by joining_date
	) as row_by_name
from emp



select * from emp
select * from personal_details
select * from dept_details

10,12,14