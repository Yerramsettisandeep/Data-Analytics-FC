create database office
use office

create table emp(
	empid int primary key,
	name varchar (20),
	dept varchar(20)
)

insert into emp values(1,'sandeep','it'),
(2,'siva','dev');
insert into emp values(3,'siva','hr'),
(4,'answe','hr');
insert into emp values(6,'asdf','de');
insert into emp values(5,'fgsd','ri');


create table emp_info(
	id int,
	num int,
	email varchar(20)
);
insert into emp_info values (1,234567,'asd@se');
insert into emp_info values (3,23567,'asd@yas');
insert into emp_info values (6,567,'gsd@yas');
insert into emp_info values (4,5787,'gsdrfa@yas');
insert into emp_info values (2,787,'gsdrfa@as');

alter table emp_info
add constraint fk_emp_info_id
foreign key (id) references emp (empid);

select * from emp
select * from emp_info


drop table emp
drop table emp_info
drop database office