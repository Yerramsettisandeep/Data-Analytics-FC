CREATE DATABASE TCL3;

USE TCL3;


CREATE TABLE Accounts (
    AccountID INT IDENTITY(1,1) PRIMARY KEY,
    HolderName VARCHAR(50),
    Balance DECIMAL(10,2)
);

INSERT INTO Accounts (HolderName, Balance)
VALUES
('Alice', 1000.00),
('Bob', 1000.00);

SELECT * FROM Accounts;

BEGIN TRAN;

UPDATE Accounts
SET Balance = Balance + 200
WHERE HolderName = 'Alice';   -- Alice sends 200

select * from Accounts;

commit;

UPDATE Accounts
SET Balance = Balance - 200
WHERE HolderName = 'Bob';

rollback tran;
select * from Accounts;

BEGIN TRAN;

UPDATE Accounts 
SET Balance = Balance + 200
WHERE HolderName = 'Alice'; 

save tran s1;

UPDATE Accounts 
SET Balance = Balance + 200 
WHERE HolderName = 'Bob';

rollback tran s1;

commit tran;


begin  

q1 save1
q2 save2
q3

roll  back save2

