create database shop
use shop 

create table product(
	product_name varchar(30),
	product_id int primary key
)
insert into product values
('fridge',1),
('mc',2),
('wash',3),
('tv',4)


create table purchase_details(
	pid int,
	price float
)
insert into purchase_details values
(1,5455),
(4,2452),
(3,2345),
(3,2346),
(2,2456)

alter table purchase_details
add constraint  fk_purchase_details_pid
foreign key (pid) references product(product_id)

alter table purchase_details
add customer_name varchar(20)

update purchase_details
set customer_name = 'mw'
where pid=1;
update purchase_details
set customer_name = 'at'
where pid=2;
update purchase_details
set customer_name = 'as'
where pid=3;
update purchase_details
set customer_name = 'ha'
where pid=4;







select * from product
select * from purchase_details
