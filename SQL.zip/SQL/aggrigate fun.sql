use company

select * from emp

select distinct(age) from emp

/*aggregate fun (sum, avg, min, max, count)*/

select sum(age) from emp
select avg(age) from emp
select min(age) from emp
select max(age) from emp
select count(age) from emp

select dept, count(age) as no_of_emp from emp
where dept != ('it')
group by dept




/*having clause*/
/*
select dept, sum(sal) as total_sal
from emp
where dept ('it')
grp by dept
having 
order by 
*/