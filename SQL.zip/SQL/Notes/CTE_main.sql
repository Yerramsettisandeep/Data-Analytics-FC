use company3
select * from emp

use company3
alter table emp
drop column email

EXEC sp_helpconstraint 'emp'

ALTER TABLE emp
DROP CONSTRAINT UQ__emp__AB6E616410C1E262


--comparing one table with another one

with id_name as(select empid, name
                from emp)
select * from id_name


with xyz as(select empid, name, salary 
from emp)
select * from xyz
where salary=7000

select * from emp
where salary=7000



WITH total_avg AS (
    SELECT AVG(salary) AS avg_sal
    FROM emp
)
select * from total_avg;

WITH total_avg AS (
    SELECT AVG(salary) AS avg_sal
    FROM emp
)
SELECT name, age, salary
FROM emp
where salary>(select * from total_avg)

WITH dept_avg AS (
    SELECT dept,AVG(salary) AS avg_sal
    FROM emp
	group by dept
)select * from dept_avg
where avg_sal>
              (select avg(avg_sal) from dept_avg)




---3. Max Salaries
WITH max_salaries AS (
    SELECT dept, MAX(salary) AS max_sal
    FROM emp
    GROUP BY dept
)
SELECT e.name, e.dept, m.max_sal
FROM emp e
JOIN max_salaries m
  ON e.dept = m.dept 
  AND e.salary = m.max_sal;


  WITH TotalSales AS (
    SELECT customer_id, SUM(amount) AS total_amount
    FROM sales
    GROUP BY customer_id
),
TopCustomers AS (
    SELECT *
    FROM TotalSales
    WHERE total_amount > 5000
)
SELECT c.name, t.total_amount
FROM customers c
JOIN TopCustomers t
    ON c.customer_id = t.customer_id;



with kammi_salary as (select min(salary) as min_salary 
                     from emp)
select * from emp
where salary=(select * from kammi_salary)
