--creating db
create database employeedb
use employeedb

--table 1
create table state(
        stateid int identity(1,1) primary key,
        statename varchar(50) not null unique
)

insert into state values
('Gujarat'),('Rajasthan'),('Uttar Pradesh')

--table 2
create table city(
        cityid int identity(1,1) primary key,
        cityname varchar(50) not null,
        stateid int,
        constraint fk_city_stateid
        foreign key (stateid) references state(stateid)
)
insert into city values
('Rajkot',1),
('Gandhinagar',1),
('Jaipur',2),
('Udaipur',2),
('Lucknow',3),
('Kanpur',3),
('Varanasi',3)

--table 3
create table company(
        companyid int identity(1,1) primary key,
        companyname varchar(50) not null,
        cityid int,
        constraint fk_company_cityid
        foreign key (cityid) references city(cityid)
)
insert into company values
('R K Infotech',1),
('Brevity Software',1),
('Evision IT Solutions',2),
('Hope IT Hub',2),
('Octal IT Solutions',3),
('Kansoft Solutions',4),
('Vexil Infotech',5),
('Billionbyte IT Solutions',6),
('Panacia Software',6),
('Oceonic IT Solutions',7),
('MRS Technology',7),
('IPX Technology',7)

--table 4
create table employee(
        empid int identity(1,1) primary key,
        empname varchar(50)not null,
        empdob date not null,
        empgender varchar(6) check (empgender in ('m','f')),
        empdoj date not null,
        empemail varchar(50) unique,
        empsalary int check (empsalary > 0),
        companyid int,
        cityid int,
        constraint fk_emp_company
        foreign key (companyid) 
        references company(companyid),

        constraint fk_emp_city
        foreign key (cityid)
        references city(cityid)
)
insert into employee values
('Anilkumar','1967-05-09','M','2005-10-25','anil@gmail.com',50000,1,1),
('Deepika','2001-03-20','F','2020-05-26','deepika@gmail.com',20000,4,2),
('Rahul','1999-04-23','M','2019-08-12','rahul@gmail.com',30000,5,3),
('Harsha','2000-12-03','F','2021-01-18','harsha@gmail.com',15000,2,1),
('Hitesh','1992-02-19','M','2010-09-16','hitesh@gmail.com',37000,7,5),
('Rajvi','1995-08-14','F','2015-07-11','rajvi@gmail.com',25000,11,7),
('Kunal','1998-03-29','M','2020-11-14','kunal@gmail.com',18000,1,1)

select * from state
SELECT * FROM CITY
SELECT * FROM COMPANY
SELECT * FROM EMPLOYEE


---------------------------QUERYs-------------------------------
--1. Get all employee details.
select * from employee

--2. Display the details of employee its name start with 'r'.
select * from employee
where empname like 'R%'

--3. Display oldest employee details.
        --using top and order by
SELECT top 1 * from employee
order by empdob 
                   --OR--
        --using min in subquery
SELECT * from employee
where empdob = (select min(empdob) from employee)

--4. Display the details of employee its name second char is 'a'.
select * from employee
where empname like '_a%'

--5. Display the details of female employee who are born in 1995.
select * from employee
where empgender = 'F' and year(empdob) = 1995

--6. Display the details of employee(both male and female) having maximum salary.
    --for highest sal
    select * from employee
    where empsalary = (select max(empsalary) from employee)

            --OR

    --to get both M and F highest sal using grpby+joins
    select e.* 
    from employee e
    join (select empgender, max(empsalary) as max_sal 
          from employee
          group by empgender) m
    on e.empgender=m.empgender
    and e.empsalary = m.max_sal

--7. Display all records but replace domain name (not change actual data)
  --like ami@gmail.com to ami@ymail.com
select empid, empname,
replace (empemail, '@gmail.com', '@ymail.com') as mail
from employee

--8.Get only second highest salary (without use CTE). 
    --using offset
select * from employee
order by empsalary desc
offset 1 row
fetch next 1 row only

    --or using subquery

select * from employee
where empsalary = (select max(empsalary) as highest_sal from employee
where empsalary <(select max(empsalary) from employee))

--9.Display the employee age (like 25 year old ).
select * from employee
where empdob >= 25
\\

--10.Update the employee name first letter capital.

--11.Display the count of employee by gender.
--12.Add column EmpContactNo and apply check constraints for contact number.
--13.Display name, salary, dob, doj of employee with its CompanyName, CityName, StateName who are not belong to any state.











-- display employee age
select empname,
concat(datediff(year, empdob, getdate()),' year old') as age
from employee;

-- update employee name first letter capital
update employee
set empname = upper(left(empname,1)) + lower(substring(empname,2,len(empname)));

-- count of employee by gender
select empgender, count(*) as total
from employee
group by empgender;

-- add contact number column with check constraint
alter table employee
add empcontactno varchar(10);

alter table employee
add constraint chk_contact
check (empcontactno like '[6-9]%' and len(empcontactno)=10);

-- employee with company, city, state who do not belong to any state
select e.empname, e.empsalary, e.empdob, e.empdoj,
c.companyname, ci.cityname, s.statename
from employee e
left join company c on e.companyid = c.companyid
left join city ci on e.cityid = ci.cityid
left join state s on ci.stateid = s.stateid
where s.stateid is null;

-- employee working at r k infotech & vexil infotech
-- salary > 15000 and salary <> 33500
select e.empname, e.empsalary, e.empdob,
c.companyname, ci.cityname, s.statename
from employee e
join company c on e.companyid = c.companyid
join city ci on c.cityid = ci.cityid
join state s on ci.stateid = s.stateid
where c.companyname in ('r k infotech','vexil infotech')
and e.empsalary > 15000
and e.empsalary <> 33500;


