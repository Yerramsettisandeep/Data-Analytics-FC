create database office

use office
create table employee(empid int identity(101, 1) primary key,
                      name varchar(20),
					  dept varchar(10),
					  salary decimal);

select * from employee



insert into employee(name, dept, salary)
values('Ajay', 'IT', 43000),
      ('Bhavya', 'Sales', 20000),
	  ('Chethan', 'IT', 40000),
	  ('Esha', 'HR', 35500),
	  ('Fathima', 'IT', 45000),
	  ('George', 'Sales', 60300),
	  ('Surya', 'IT', 50200),
	  ('Vicky', 'IT', 70000),
	  ('Nethra', 'HR', 52000),
	  ('Sachin', 'HR', 35000),
	  ('Sagar', 'Sales', 30000)


create table empdetails(id int,
                        num int,
						email varchar(30));

select * from empdetails
select * from employee

insert into empdetails values(102, 12345, 'ajay@gmail.com')

alter table empdetails
add constraint fk_empdetails_id
foreign key (id)
references employee(empid)
