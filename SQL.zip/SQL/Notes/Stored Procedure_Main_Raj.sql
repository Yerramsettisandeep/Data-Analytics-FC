create database DB

use DB

CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeName VARCHAR(100),
    Salary INT,
    Department VARCHAR(50),
    JoiningDate DATE
);

select * from Employees

INSERT INTO Employees (EmployeeName, Salary, Department, JoiningDate)
VALUES ('Riya', 55000, 'Marketing', '2024-04-12');


INSERT INTO Employees (EmployeeName, Salary, Department, JoiningDate)
VALUES 
('Riya', 55000, 'Marketing', '2024-04-12'),
('Karan', 60000, 'HR', '2023-12-15'),
('Meera', 45000, 'Finance', '2024-02-01'),
('Arjun', 70000, 'IT', '2024-03-10'),
('Sneha', 52000, 'Finance', '2024-04-01'),
('Rohit', 65000, 'IT', '2024-05-12'),
('Priya', 48000, 'Marketing', '2023-11-20'),
('Vikram', 75000, 'Data Analytics', '2024-06-18'),
('Nisha', 55000, 'HR', '2024-07-03'),
('Anand', 47000, 'Operations', '2023-10-10');

update Employees
set EmployeeName= 'Rajesh', Salary=35000
where EmployeeID=1

--A Stored Procedure (SP) is a pre-compiled block of SQL code stored inside your database.
--You run it whenever needed � like calling a function.

EXEC GetSalesData;

--2. How do you create a simple stored procedure?
CREATE PROCEDURE xyz
AS
BEGIN
    SELECT EmployeeName, salary FROM Employees;
END;

execute xyz

alter procedure xyz
as
begin
select EmployeeName from employees
end


alter procedure Getnamesalary1
as
begin 
     select EmployeeName from employees
end

EXEC GetAllEmployees;

--3. How to create a stored procedure with a parameter?

Create Procedure GetEmployeeByID1
   @EID int
AS
BEGIN
   select * from Employees where EmployeeID=@EID
END;

EXEC GetEmployeeByID1 @EID=7
execute GetEmployeeByID1 @EID=7
GetEmployeeByID1 @EID=7


drop procedure xyz






--Alter the stored procedure

alter procedure GetAllEmployees
AS
BEGIN
     select EmployeeName from Employees
END

EXEC GetAllEmployees

--Delete a procedure

drop procedure GetAllEmployees

--What are input and output parameters?
--Input: user gives value
--Output: SP returns value

--When your stored procedure has an OUTPUT parameter, 
--SQL Server needs a place to store the returned value.

CREATE PROCEDURE CountEmployees
    @Total INT OUTPUT
AS
BEGIN
    SELECT @Total = COUNT(*) FROM Employees;
END;
Go

DECLARE @EmpCount INT;        
--Create a variable to store output

EXEC CountEmployees 
     @Total = @EmpCount OUTPUT;   
--Output flows into @EmpCount

PRINT @EmpCount;            
--Show the value







