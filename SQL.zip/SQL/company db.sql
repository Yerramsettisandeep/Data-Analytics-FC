use company

create table emp1(
	empid int,
	name varchar(10),
	salary float,
	dept varchar(10),
	email varchar(20)
)

insert into emp1 values
(1,'t',33000.00,'hr','dfjk@gfd'),
(2,'g',63000.00,'hr','dfask@gfd');
insert into emp1 values
(3,'f',34000.00,'it','afjk@gfd',40)

alter table emp1 
alter column empid int not null;


alter table emp1
add constraint pk_empid_emp1
primary key(empid);

alter table emp1
add constraint uq_emailid_emp1
unique (email);

alter table emp1
add constraint ck_salary_emp1
check (salary>10000);


alter table emp1
alter column dept varchar(10);

alter table emp1
add constraint df_dept_emp1
default 'working' for dept;

alter table emp1
add age int

alter table emp1
add constraint ck_age_emp1
check (age>18);
select * from emp1;

select * from emp1
update emp1
set age = 
case
empid
when 1 then 32
when 2 then 33
else age
end

select * from emp1