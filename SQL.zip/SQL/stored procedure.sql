------------------------------------Stored Procedure------------------------------------
/*
--stored procedure is a grp of t-sql (transcat) ststements
if you have a situation where you write the same query over and over again, 
you can save that specific query as a stored procedure and call it just by its name
*/

use company1

select* from emp

--creating another table(not temp) which we can use
create procedure all_name_sal
as
begin 
	select name, salary from emp
end;

execute all_name_sal;

--getting details by id
create procedure details_by_id
@id int
as
	begin
		--select empid=id from emp
		select * from emp where empid=@id
	end;

execute details_by_id @id = 102


---alter procedure
ALTER procedure all_name_sal
as
begin 
	select name from emp
end;

execute all_name_sal;

/*
---what are input and output parameters?
input: user gives value
output: sp returns values

when your sp has a output patameter, SQL server needs a place to store returned values
*/
drop procedure all_name_sal


create procedure grender_dept
@g varchar(10), @d varchar(10)
as
begin 
	select * from emp
	where gender = @g and dept = @d
end

execute grender_dept 'female','hr'


---count by dept (how many)
create procedure dept_count
@d varchar(10), 
@c int output
as
	begin
		select @c = count(empid)
		from emp
		where @d= dept
	end

declare @cspace int
execute dept_count @d = 'hr', @c= @cspace output
print @cspace

--display name by id
create procedure id_name
@id int
as
	begin
		--select empid=id from emp
		select name 
		from emp where empid=@id
	end;

execute id_name @id = 102

--dept wise details
create procedure dept_details
@d varchar(10)
as
begin
	select * from emp
	where dept=@d
end

execute dept_details @d='hr'
drop procedure dept_details 
-----------------------------------------------ERRORS----------------------------------------------------
select * from emp

--getting details by dept and emp details
create procedure details_by_dept
@dept varchar(30)
as
	begin
		--select empid=id from emp
		select * from emp 
		where dept=@dept
	end;

execute details_by_dept @dept = 'hr'