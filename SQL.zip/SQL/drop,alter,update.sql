create database branch_office

use branch_office

create table emp(
	emp_id int primary key,
	emp_name varchar(30) not null,
	salary int 
)

INSERT INTO emp VALUES
(1, 'ram', 35000),
(2, 'lakshman', 40000),
(3, 'bharat', 45000),
(4, 'shatrugna', 30000),
(5, 'hanuman', 50000);


create table personal_info(
	emp_id int foreign key references emp(emp_id),
	phno bigint not null,
	age int not null,
	email_id varchar(30) unique
)

INSERT INTO personal_info VALUES
(1, 9876543210, 25, 'sssssssss@sss'),
(2, 9876543222, 27, 'ddddddddd@ddd'),
(3, 9876543333, 24, 'eeeeeeeee@eee');


/* --- to drop primary key
alter table emp
drop constraint name

alter table emp
alter column emp_id int null
*/

alter table emp
alter column emp_name varchar(15)

alter table emp 
add dept varchar(10)

update emp
set dept = 'da'
where emp_id = 1

update emp
set dept = 'da'
where emp_id = 2

update emp
set dept = 'anly'
where emp_id = 3

update emp
set dept = 'fe'
where emp_id = 4

update emp
set dept = 'be'
where emp_id = 5

alter table emp
drop row (dept)

--Rename column
/*exec sp_rename 'tablename.oldcol name', 'new column name', 'column'*/
execute sp_rename 'emp.dept' ,'department', 'column'


SELECT * FROM emp;
SELECT * FROM personal_info;


drop table personal_info
drop database branch_office