-- Step 1: Create a database
CREATE DATABASE DTD;

USE DTD;

-- Step 2: Create a table
CREATE TABLE Employees (
    EmpID INT IDENTITY(1,1) PRIMARY KEY,
    EmpName VARCHAR(50)
);

-- Step 3: Insert some sample data
INSERT INTO Employees (EmpName)
VALUES ('Alice'), ('Bob'), ('Charlie');

-- Check the data
SELECT * FROM Employees;

---------TRUNCATE----------

BEGIN TRAN;  -- start a transaction

TRUNCATE TABLE Employees;  -- empties the table quickly

-- Check what�s in the table now (should show 0 rows)
SELECT * FROM Employees;

ROLLBACK TRAN;  -- undo everything since BEGIN TRAN

-- Check again after rollback
SELECT * FROM Employees;


------DELETE--------

BEGIN TRAN;  -- start a transaction

DELETE FROM Employees WHERE EmpName = 'Bob';  -- remove Bob only

-- Check table now (Bob should be gone)
SELECT * FROM Employees;

ROLLBACK TRAN;  -- undo the delete

-- Check table again (Bob should be back)
SELECT * FROM Employees
where EmpID=1


create table t1(name varchar(10))

insert into t1 values('raj'), ('Surya')

create table t2(name varchar(10))
insert into t2 values('aaa'), ('bbb')

select * from t1
select * from t2

begin tran
truncate table t1
truncate table t2
rollback tran

begin tran
truncate table t2
rollback tran


-------DROP------

DROP table Employees;