use forest
select * from animal
select * from ct2



select c.aid, a.name as animal_name, c.cname
from animal a
inner join ct2  c
on a.id=c.aid

--on common id's will be displayed

select animal.id, animal.name, ct2.cname, ct2.years
from animal --left table
left join ct2 --right table
on animal.id=ct2.aid

alter table ct2
drop constraint fk_ct2_aid


insert into ct2(aid, cname, years)
values(510, 'naveen', 6),
      (511, 'praiwal', 5)

select animal.id, animal.name, ct2.cname, ct2.years
from animal --left table
right join ct2 --right table
on animal.id=ct2.aid

select animal.id, animal.name, ct2.cname, ct2.years
from animal --left table
full join ct2 --right table
on animal.id=ct2.aid

select animal.id, animal.name, ct2.cname
from animal --left table
cross join ct2--right table

select * from ct2
select * from animal


--join/inner join
--rigt join/right inner join
--left join/left inner join
--full join/full outer join

