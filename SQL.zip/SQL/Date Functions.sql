---current day,year,month,time
select getdate()       --yyyy--mm--dd--hh-mm--ss

---only year
select year(getdate())		/*OR*/  select year('2024-03-12')

--omly month
select month(getdate())		/*OR*/	select month('2004-05-05')	

--only date
select day(getdate())		/*OR*/	select day('2004-05-05')	

----knowing WHICH the DATENAME(LIKE MON, TUE, .....)
SELECT DATENAME(weekday, getdate())

--finding which min 
SELECT DATENAME(minute, getdate())

--finding which quarter(there are 4 quarters(q1=jan,fed,mar),(q2 = apr,may,jun), (q3=july,aug,sept), (q4=oct,nov,dec))
SELECT DATENAME(quarter, getdate())

--adding 2 days
select dateadd(day,2,getdate())

--adding 2 months
select dateadd(month,2,getdate())

--adding 2 years
select dateadd(year,2,getdate())

--no of days between two dates
select datediff(day, '2004-05-05','2006-01-06')

--no of month between two dates
select datediff(month, '2004-05-05','2006-01-06')

--no of years diff bw 2 dates
select datediff(year, '2004-05-05','2006-01-06')

--present date diff to dob
select datediff(year,'2004-05-05',getdate())

---Formats
select format(getdate(),'yyyy-mm-dd')
select format(getdate(),'mm-yyyy-dd')
select format(getdate(),'mm-dd-yyyy')



use company1
--finding emp doj
select empid,name,doj
from emp

----find emp whic day the are joined
SELECT empid, name, DATENAME(weekday, doj)
from emp



select * from emp