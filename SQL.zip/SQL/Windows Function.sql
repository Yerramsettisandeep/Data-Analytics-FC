use company1
select* from emp

-------------------------------windows column-----------------------------------------------------------
--row number
--rank
--dense_rank
--min
--max
--sum
--avg
--lag
--lead
--first value
--last value
--N-Tile


-->row_number 
--its for adding extra columns
select * , 
	row_number() over(
	partition by dept
	order by salary desc
	) as row_by_sal
from emp

--by Rank( knowing position ), 
select *,
	rank() over(
	--partition by dept
	order by salary
	) as row_by_sal
from emp
--dense rank(nxt number)
select *,
	dense_rank() over(
	--partition by dept
	order by salary
	) as row_by_sal
from emp


--min

--find the 2nd highest salary in each dept
select *
from (
	select *,
		row_number() over(
		--partition by dept
		order by salary
		) as row_by_sal
	from emp) as rank_num
where row_by_sal=2


--min & max & avg & sum
select *,
	avg(salary) over(
	--partition by dept
	order by name desc
	) as avg_sal
from emp


--lead (knowning te next persons salary r deptr gender r etc)
select * , 
	lead(salary) over(
	--partition by dept
	order by empid
	) as row_by_sal
from emp

--lag (knowning te previous persons salary r dept r gender r etc)
select * ,
	lag(salary) over(
	--partition by dept
	order by empid
	) as row_by_sal
from emp

--first value
select *,
	first_value(empid) over(
	--partition by dept
	order by empid
	) as first_emp
from emp

--last vlaue
select *,
	last_value(empid) over(
	--partition by dept
	order by empid desc
	rows between unbounded preceding and unbounded following
	) as last_emp
from emp

--N Tile (grouping ppl to grps)
--ex: 1 to 10 ppl they want to divide into 4 grps (sport grp);
--no of ppl dicided by no of sport remaing (10/4)=2.22 roundup 3 so first 3 ppl r in 1st sport,
--same next 7 ppl and 3 sports left now  sp 7/3=2.33 =3 2nd sport same for all.

select *,
	ntile(3) over(
	order by age
	) as age_grp
from emp