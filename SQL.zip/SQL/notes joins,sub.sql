use sqlmasterdb

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(50),
    City VARCHAR(50)
);
INSERT INTO Customers VALUES
(1, 'Rohit', 'Hyderabad'),
(2, 'Anita', 'Delhi'),
(3, 'Suresh', 'Mumbai'),
(4, 'Priya', 'Chennai');

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    CustomerID INT     -- foreign key (later)
);
INSERT INTO Orders VALUES
(101, '2024-01-10', 1),
(102, '2024-02-12', 1),
(103, '2024-03-05', 2),
(104, '2024-04-15', 4),
(105, '2024-05-22', 10);   -- CustomerID 10 does NOT exist


---create foreign key
alter table orders
add constraint fk_orders_cus
foreign key (customerid) references customers(customerid);


/*
GROUP BY: groups rows that have the same value.
Think of it like making �buckets�.
HAVING: is used after GROUP BY
It filters groups (not rows)
*/

--INNER JOIN
select c.customername, c.city, o.orderid,o.orderdate
from customers c
inner join orders o
on c.customerid=o.customerid

select c.customername,c.city,o.orderid
from customers c
inner join orders o
on c.customerid=o.customerid

select c.customername,count(*) as total_orders
from customers c
inner join orders o
on c.customerid=o.customerid
group by Customername
having count(*) >1


select c.city,count(*)as total_cus
from customers c
inner join orders o
on c.customerid=o.customerid
group by city
having count(*) >=2

select c.customername, count(*) as total_orders
from customers c
inner join orders o
on c.customerid=o.customerid
group by CustomerName
having count(*)>1
order by total_orders desc


---left join
select c.customername, o.orderid,o.orderdate
from customers c
left join orders o
on c.customerid=o.customerid

---RIGHT JOIN
select c.customername, o.orderid,o.orderdate
from customers c
RIGHT join orders o
on c.customerid=o.customerid

--full join
select c.customername, o.orderid,o.orderdate
from customers c
full join orders o
on c.customerid=o.customerid

--self join
select a.customername, b.customername, a.city
from customers a
join customers b
on a.city = b.city
and a.customerid != b.customerid


------------------------------SUB QUERY-------------------------
---Find the latest order date for all orders.
select max(orderdate) as latestdate
from orders;

--Find customers who placed the latest order.
select customerid, orderid,orderdate
from orders
where orderdate = (select max(orderdate) from orders)

--Find customers who have at least 1 order.
select*from customers
where customerid in (select customerid from orders);



--------------------------WINDOWS FUNCTION---------------------

----ROW_NUMBER()
SELECT name,dept,salary,
    row_number() over(
    --partition by dept
    order by salary
    ) as row_num
from emp;














select*from customers
select*from orders
