create database school
use school
create table first(
	roll_number int,
	name varchar(15),
	phno int,
);

select * from first
insert into first(roll_number, name, phno)
values (1,'sandeep',112),
	   (2,'siva',944),
	   (3,'answe',600)

create table second(
	roll_number int,
	name varchar(15),
	fav_sub varchar(15),
)
insert into second(roll_number, name, fav_sub)
values (4,'v','bio'),
	   (5,'r','stats')

select * from second