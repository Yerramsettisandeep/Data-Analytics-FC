--Mathematical Functions

select round(3, 3.166666)

--ABS absolute number- only positive number
select ABS(-0.45)

--CEILING- if you are passing decimal number ceiling returns highest number
--FLOOR- if you are passing decimal number ceiling returns lowest number

select ceiling(0.43)
select ceiling(1.1)
select ceiling(-0.43)
select ceiling(-1.1)

select floor(-0.43)
select floor(-1.1)

--POWER- returns the power of a function

select power(5,2)
select power(3,3)

--SQUARE square root

select square(9)

--RAND- gives random numbers

select rand(1)--- if we pass a seed value of 1 there is a fixed value
select rand(5)
select rand()-- if we dont pass a seed value it keeps changing everytime you execute
select (rand() * 100)

select floor((rand() * 100))

--ROUND-- rouds the given numeeric expression based on the given length-- how many places
--round the number--right side

select round(8.67896, 2)--- if we dont specify we gives round value
select round(5.423, 2)

--truncate the number
select round(8.67896, 4,1)-- if we specify it takes just 2 and remaing as 0(better to put 1)
select round(5.423, 2, 1)-- takes first two number and displays 0 for rest

--round of the left side
select round(675.423, -2)
select round(675.423, -1)
