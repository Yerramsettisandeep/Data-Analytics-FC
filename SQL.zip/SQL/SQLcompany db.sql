create database company
use company
create table emp(
	emp_id int primary key, 
	emp_name varchar(15) not null,
	age int check (age>=21),
	email varchar(25) unique,
	dept varchar(10) default 'Worker'
)

insert into emp values (1, 'i', 22, 'asdfghjkl@dsfja', 'hr');
insert into emp values (2, 'w', 32, 'asdfeghjkl@dsfja','hr');
insert into emp values (3, 'g', 33, 'asdfghjkoi@dsfja', 'it');
insert into emp values (4, 'g', 33, 'asdfghjkoo@dsfja', 'it');
insert into emp values (5, 'j', 22, 'ayysdfghjkl@dsfja', 'hr');
insert into emp values (6, 'j', 43, 'asdfghjkoo@jhsfja', 'sales');
insert into emp values (7, 'g', null, null, null);

insert into emp values 
(8, 'i', null, 'newmail8@dsfja', 'hr'),
(9, 'g', 33, 'asdfsdgdghjkoo@dsfja', default),
(10, 'g', 33, 'asdfdffghjkoo@dsfja', default),
(11, 'i', 22, 'newmail11@dsfja', 'hr');

insert into emp values(12,'oti', null,'sfhh@hf',default);

select * from emp;
-- primary key(not null+unique)
-- not null (it should be filled)
-- check (it should satisify the condition)
-- unique (it should be diff)
-- default (it takes the default value)

delete from emp 
where emp_id in (8, 9, 10, 11);

drop table emp