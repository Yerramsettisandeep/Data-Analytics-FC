use family
select * from kids_parents
select * from members

create table family2(pid int, name varchar(10), kid int)

insert into family2 values(1, 'Ajay', 4),
                         (2, 'Vijay', 6),
						 (3, 'Sam', 5),
						 (4, 'Bob', null),
						 (5, 'John', null),
						 (6, 'Jessy', null)

select * from family2

select p.name as parent_name, k.name as kid_name
from family2 p
join family2 k
on k.pid=p.kid